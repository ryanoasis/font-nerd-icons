
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 041ef9202ccdba9705b9f96a1fc838b79822a93d
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Feb 21 14:01:56 2025 +0100
        
            Add information if font is monospaced
            
            [why]
            Some patched fonts will for sure look strange in a terminal and there is
            no warning for users.
            
            [how]
            Add information to fonts.json and that will generate a not in the font's
            readme. This information can also be displayed on the nerdfonts.com
            website.
            
            [note]
            Fixes: #1804
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
